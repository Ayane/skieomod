# Alpine Valley

An independent map with a generated 1024 x 1024 metre slope.

Package ID: `author.alpine-valley`. Initial version: `0.1.0`.

## First steps

Run these commands from this project directory:

```sh
skieomod build
skieomod test
skieomod run
```

Creation, validation and builds need Python 3.10+ and the installed `skieomod`
command. Running needs Ski-E-O!, Steam and Custom Map/UE4SS; use `skieomod setup`
to detect the game and install the loader. For Lua syntax checks, install Lua 5.4
and run `skieomod test --check-scripts`.

## Project files

| File | Purpose |
| --- | --- |
| `custom-map.json` | Package identity, metadata, dependencies and runtime content |
| `Scripts/main.lua` | Commented Lua entry point to customize |
| `workshop.json` | Workshop settings, initially private |
| `preview.png` | Placeholder preview; replace with your own screenshot |
| `docs/` | Manifest, scripting, development and publication guides |
| `.gitignore` | Keeps generated `bin/` and `obj/` out of source control |
| `Terrain/heightmap.r16` | 65 x 65 little-endian unsigned 16-bit elevation samples |
| `Vegetation/forest.json` | Editable tree positions in world metres |

`skieomod build` produces `bin/author.alpine-valley-0.1.0.skieomap`. Only content referenced
by the manifest is packaged; this README and the authoring guides remain in the
source project. Share the source directory separately to include its documentation.

## Guides

- [Manifest fields and dependencies](docs/manifest.md)
- [Lua entry point and runtime](docs/scripting.md)
- [Build, test, run and troubleshooting](docs/development.md)
- [Prepare a Steam Workshop article](docs/workshop.md)
- [Terrain encoding and preview](docs/terrain.md)
- [Place trees with JSON](docs/vegetation.md)

Use `skieomod help`, `skieomod help create` or `skieomod COMMAND --help` for CLI
examples. `skieomod new` remains an alias for `skieomod create`.
