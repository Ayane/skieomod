# Terrain source

The starter map is a skiable 1024 x 1024 metre slope. Its heightmap contains
65 x 65 vertices, spaced 16 metres apart.
The complete file has `65 * 65 * 2 = 8450` bytes.

Maps are not capped at 8 km. Choose the extent and resolution at creation:

```sh
skieomod create map --output large-map --size 16000 12000 --spacing 8
```

Both lengths must be multiples of the spacing. Creation selects a rendering
stride that keeps the starter mesh modest; increase source spacing to reduce
file size, or adjust the rendering stride to change the visible detail.
Creation allows at most 32 MiB of source samples and 16384 vertices per axis.
The native cache remains 2017 x 2017 samples resampled over the full extent;
its ground spacing grows with map size. Visible terrain and physical collision
use the portable source and the rendering stride.

`Terrain/heightmap.r16` stores row-major **unsigned 16-bit little-endian** samples,
with rows ordered north to south. There is no file header. The template uses:

```text
height_in_metres = sample * 0.01 + 0
```

These values come from `terrain.source.height_scale_meters` and
`height_offset_meters`. `terrain.source.vertices` specifies the grid size;
`spacing_meters` specifies its spacing. Keep `terrain.size_meters` consistent
with `(vertices - 1) * spacing_meters`, and `terrain.elevation_meters` equal to
the decoded minimum and maximum heights.

## Replace the heightmap

With skieomod 1.10 or later, put your original heightmap in the project and
add this top-level configuration to `custom-map.json`:

```json
"build": {
  "heightmap": {
    "file": "Terrain/source-heightmap.png",
    "spacing_meters": 8,
    "elevation_meters": [800, 2200]
  }
}
```

Then run `skieomod build`. PNG16 dimensions, terrain size, elevation encoding,
centred origin and normalized preview are calculated automatically. The build
updates derived terrain metadata and generates portable R16 only after validation;
replaced files are backed up in `.heightmap-backups/`. Keep the original file:
later builds and `run` use the stored settings again. `test` checks the same
prepared terrain without writing derived files. No separate converter is needed.

Use a non-interlaced 16-bit grayscale PNG without alpha, or headerless R16.
For R16 also supply `vertices: [width, height]`, and `format: "r16be"` for
big-endian data. Use your actual sample spacing and elevation endpoints, or
`height_scale_meters` and `height_offset_meters` from your exporter instead.
The original input must not use the reserved output path `Terrain/heightmap.r16`.
`build.heightmap.sample_step` optionally overrides the automatic rendering stride.
See `skieomod help build` and the
[heightmap tutorial](https://skieomap.emillon.fr/tutorials/heightmap/).

For manual imports:

Export a headerless R16LE grid and update the source fields, map size and
elevation range together. `terrain.origin_centimeters` positions the grid in
game coordinates; the starter uses `[-51200, -51200, 0]` to center the slope.
The CLI does not automatically rewrite terrain metadata after binary edits.

`terrain.preview.samples` is a small rectangular height grid normalized to
0..1, currently 9 x 9. Update it to reflect your new relief. Preview dimensions
must be between 3 and 33 on each axis. For a non-flat terrain, normalize with
`(height - minimum) / (maximum - minimum)`.

`terrain.runtime.sample_step` selects the rendering sample stride;
`tile_quads` controls mesh tile size; `snow_offset_centimeters` offsets snow.
Start with the template values and validate changes with `skieomod test`.
Use `skieomod run` to inspect terrain, collision and snow in the game.

Only portable source data belongs in a `.skieomap`; cooked Unreal containers
are excluded. Keep attribution and license records for any imported terrain.
