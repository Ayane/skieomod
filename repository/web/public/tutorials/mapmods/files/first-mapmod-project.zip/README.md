# Your first mapmod

Two source projects: mountain-life (the mod) and practice-mountain (the map).
From this folder:

```sh
skieomod build mountain-life --check-scripts
skieomod build practice-mountain --dependency mountain-life --check-scripts
skieomod run practice-mountain --dependency mountain-life
```

Read mapmod-tutorial.md for the complete tutorial. The example logs field
reports; it does not spawn animals. Lua 5.4 / luac is needed for syntax checks.
