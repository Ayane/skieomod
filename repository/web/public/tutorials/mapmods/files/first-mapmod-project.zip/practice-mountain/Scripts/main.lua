-- Map API 1.0 entry point, shared by maps and mapmod dependencies.
-- The loader calls this function once per map session and supplies its API.
-- Register callbacks here; wait for map.ready before changing the world.
-- See docs/scripting.md for events, timers and asset declarations.
return function(api)
    -- This callback runs after the terrain is available, including on save loads.
    -- Keep it short; use API timers for work that needs to run later.
    api:on("map.ready", function()
        api:log("Welcome! Your creation is ready.")

        -- Edit Vegetation/forest.json; build compiles it to SKXY. Z follows terrain.
        -- The loader holds the loading screen until insertion is complete.
        -- This also rebuilds the forest when restoring a save.
        -- See docs/vegetation.md; Custom Maps 1.11 or later is required.
        api:load_forest_skxy("Vegetation/Generated/forest.skxy")

        -- Example (uncomment to run): add starting funds to the current session.
        -- Requires the gameplay permission declared in the manifest.
        -- api.game:add_funds(1000)
    end)

    -- Release your own session resources here when the map closes.
    -- The loader automatically cancels API timers and unregisters callbacks.
    api:on("map.unloading", function()
        api:log("Your creation is unloading.")
    end)
end
