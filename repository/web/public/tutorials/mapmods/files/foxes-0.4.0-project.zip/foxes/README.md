# Forest foxes source project

Read docs/mapmod-tutorial.md and docs/mapmods.md. From the foxes folder:

```sh
skieomod build . --check-scripts
skieomod run .
```

run creates a local preview map; F7 cycles through its foxes.
To rebuild the animated asset from the original Fox Anatomy Collada ZIP:

```sh
python3 -m pip install numpy Pillow
python3 tools/prepare_fox.py /path/to/fox-anatomy.zip --output Assets
```

The original anatomy ZIP is not supplied. Keep CREDITS.txt and LICENSE with
redistributed derivatives: code is MIT; the model and textures are CC BY 4.0.
