# Development workflow

Run commands from the project directory, or pass that directory as the optional
argument: `skieomod build "path to project"`. Creation refuses to overwrite
existing files, including authoring documentation.

1. Edit the manifest and `Scripts/main.lua`.
2. Run `skieomod build` to validate and produce a reproducible ZIP in `bin/`.
3. Run `skieomod test --check-scripts` if Lua 5.4 / luac is installed.
4. Run `skieomod test --check-dependencies` to check installed Workshop mods.
5. Run `skieomod run` to rebuild, install locally and start the game via Steam.

`skieomod test` also accepts a manifest or an existing `.skieomap` / `.skieomod`.
`skieomod build --output PATH` chooses an archive path. A failed build preserves
the previous valid archive. Files absent from manifest references are excluded.
Commit your source files and docs, not generated `bin/` and `obj/` content.

## Game setup

```sh
skieomod setup
skieomod config
```

Setup detects Steam game/demo installations and remembers the game, maps and
UE4SS paths. If needed, use `skieomod setup --game-dir "PATH TO GAME"`.
Before Workshop opens, close the game and use `skieomod update --check` then
`skieomod update` to apply the latest Custom Map loader from skieomod.emillon.fr.
This preserves settings and maps and backs up replaced files. Use
`skieomod update --archive CustomMap-Mod-VERSION.zip` for a specific test release.
Windows and Linux/Proton support launching; macOS supports authoring only.
Under Proton, launch the game once from Steam and close it before setup so its
prefix exists. Setup downloads UE4SS on first installation when needed.

## Troubleshooting

| Symptom | Action |
| --- | --- |
| No unique project manifest | Run in a project directory containing one root manifest, or pass its path |
| Missing referenced file | Check its relative path and spelling in the manifest |
| Lua syntax check unavailable | Install Lua 5.4 with `luac5.4` or `luac`, or omit `--check-scripts` |
| Missing/conflicting dependency | Install the required Workshop mod and check its ID and compatible package version |
| Game installation ambiguous | Select it with `--game-dir`; inspect saved values with `skieomod config` |
| Steamworks client not connected | Use `publish --prepare` or `list --installed`; remote commands need a separate native client |

For more examples, run `skieomod help build`, `skieomod help test` and
`skieomod help run`.
