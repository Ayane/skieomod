# Manifest reference

Edit `custom-map.json` as strict JSON: comments and trailing commas are not supported.
These notes explain fields outside the JSON so it stays directly installable.
Run `skieomod test` after changes.

| Field | Meaning |
| --- | --- |
| `format.name`, `format.version` | Package format; keep the template values unless migrating formats |
| `id` | Stable namespaced lowercase ID, e.g. `author.my-creation`; no spaces or filesystem paths |
| `metadata.name` | Display title |
| `metadata.version` | Package semantic version, initially `0.1.0`; increment for releases |
| `metadata.authors` | Credits; replace `Your name` if you did not pass `--author` |
| `metadata.description` | Describe the content before publication |
| `metadata.language` | Content language tag, initially `en`; e.g. `fr` |
| `metadata.license` | Initially `MIT`; choose your license and supply its terms and resource credits before sharing |
| `dependencies` | Required or optional mod dependencies; an empty list needs no other mods |

## Dependencies

Add a mod to `dependencies`, for example:

```json
{"id": "author.snow-tools", "version": "^1.0.0", "workshop_id": "1234567890"}
```

`id` identifies the package. `version` describes compatibility (`*`, `=1.0.0`,
`^1.0.0`, `~1.0.0` or comparison ranges). `workshop_id` is a decimal **string**
identifying its Steam article; required dependencies need it before publication.
Steam supplies the current article content, not historical package versions.
Set `optional: true` for an optional dependency. Cycles and version conflicts fail
validation. `skieomod test --check-dependencies` checks locally installed Workshop
manifests; it does not download missing dependencies.

## Map API script

`script.language: "lua"`, `script.api: "1.0"` and `script.entry:
"Scripts/main.lua"` select the entry point. `script.permissions: ["gameplay"]`
allows documented gameplay actions. Use the supplied `api`; ordinary scripts
do not have unrestricted filesystem, process or Unreal access.

`terrain` defines the source heightmap, dimensions, elevation range and preview;
see [terrain.md](terrain.md). `content.assets` lists additional portable source
files, readable with `api:read_asset(path)`. The terrain source and script entry
are already packaged automatically: do not list them again in `content.assets`.
Maps use source data and cannot embed cooked `.pak`, `.ucas` or `.utoc` containers.
