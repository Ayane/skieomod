# Lua scripting

The commented entry point is `Scripts/main.lua`. Keep source in UTF-8.
`skieomod test --check-scripts` checks syntax using Lua 5.4; it does not execute
the game or validate Unreal object names. Check behavior in game with `run`.

## Entry point and events

Return `function(api)`. The loader calls it once per map session; register your
event callbacks inside it. `map.ready` is emitted after the terrain is available,
including when restoring a save. Keep callbacks short and avoid duplicating
saved objects when rebuilding your scene. `map.unloading` is the cleanup event.

```lua
return function(api)
    api:on("map.ready", function()
        api:log("Ready")
        -- With the gameplay permission declared in the manifest:
        -- api.game:add_funds(1000)
    end)
end
```

Use `api:off(event, callback)` to remove a handler. Other supported events include
`map.before_load`, `map.after_load`, `map.terrain_loaded`, `map.load_failed`,
`calendar.month_changed`, `calendar.year_changed`, `weather.changed`,
`placeable.built`, `placeable.removed`, `trail.created` and `trail.removed`.

## Timers, loading and resources

- `api:after(milliseconds, callback)` schedules a one-time callback.
- `api:every(milliseconds, callback)` repeats at intervals of at least 16 ms;
  return `false` from your callback to stop.
- `api:hold_loading()` reserves an asynchronous task **inside** `map.ready`.
  Call its returned completion function when finished, or pass an error message.
- `api:loading_progress(stage, fraction)` reports loading progress from 0 to 1.
- `api:read_asset(relative_path)` reads data declared in `content.assets`.
- `api:load_forest_skxy(relative_path, options)` reads compiled SKXY and holds
  loading until complete; call once inside `map.ready` (Custom Maps 1.11+).

The loader cancels API timers and unregisters callbacks when the session closes.
Ordinary scripts use a sandbox: do not rely on `io`, `os`, arbitrary `require`
or UE4SS globals. Declare assets in the manifest; see [manifest.md](manifest.md).
