# Publication

## Publish to the web catalogue

Create a publishing token at https://skieomod.emillon.fr/account and set
CUSTOM_MAP_TOKEN in your terminal, then run `skieomod publish` in this project.
The map appears in New Game → Custom Map → Web. Publish dependencies first.
Increase metadata.version before releasing an update; versions are immutable.

Steam Workshop integration is in preparation; the following commands are
explicit options and do not replace web publication.


## Prepare offline

Update the manifest title, description, authors, language, license and package
version. Credit and license any imported resources. Replace `preview.png` with
your own PNG/JPG/GIF image under 1 MiB, and edit `workshop.json`:

| Field | Meaning |
| --- | --- |
| `version` | Settings format, keep `1` |
| `app_id` | Consumer Workshop AppID, initially the full game's `"4493130"` |
| `published_file_id` | `"0"` creates an article; an existing decimal-string ID updates it |
| `visibility` | Initially `private`; also `public`, `friends` or `unlisted` |
| `preview_file` | Image path relative to the project, initially `preview.png` |

```sh
skieomod publish --prepare
```

This validates and builds the project, then creates `bin/workshop/`:

- `content/`: unpacked manifest and referenced runtime files;
- `preview.png`: separate preview;
- `publish-request.json`: request for a native Steamworks client;
- `workshop.vdf`: SteamCMD test configuration.

Required mod dependencies must specify their `workshop_id` before preparation.
The local ZIP is a development artifact; Steam receives unpacked content.
Authoring docs and Workshop settings are kept in your source project.

## Publish through a native client

The native Steamworks client is not included with skieomod. When supplied by
the game integration, configure it and publish using the local Steam session:

```sh
skieomod --steam-client "PATH TO CLIENT" config
skieomod publish --steam --changenote "Initial release"
```

The returned article ID is saved in `workshop.json` for subsequent updates.
Accept the Workshop legal agreement if Steam requires it. `--item-id`,
`--app-id`, `--preview` and `--visibility` override the stored settings.
The demo AppID is `5012760`; access to another AppID's Workshop is not assumed.
The VDF is for SteamCMD testing and does not publish complete UGC metadata,
tags or dependency links. Use `skieomod help publish` for more CLI examples.
