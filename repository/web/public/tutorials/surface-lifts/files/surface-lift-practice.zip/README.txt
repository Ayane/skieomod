# Surface lift practice

Open practice-mountain/custom-map.json in skieomod editor.
The native one-seat lift is named Practice platter. Its scene coordinates are
in metres; the mapmod route uses world centimetres. Z is sampled at runtime.

From this extracted folder, build and play the separate source projects:

    skieomod build surface-lifts
    skieomod build practice-mountain --dependency surface-lifts
    skieomod run practice-mountain --dependency surface-lifts

The two source projects are separate packages. Do not copy mod assets into the map.
Read https://skieomod.emillon.fr/tutorials/surface-lifts/ for the full guide.
Use the ordinary game tools to add trails, staff and the rest of your resort.
